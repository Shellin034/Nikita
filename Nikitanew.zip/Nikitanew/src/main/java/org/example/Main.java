package org.example;



public class Main {
    public static void main(String[] args) {


        Dog dog = new Dog(1, "Bim");
        Dog dog2 = new Dog(2, "Bars");

        dog.printInfo();
        dog2.printInfo();

        int[] Dog = new int[2];
        Dog[0] = 1;
        Dog[1] = 2;
        for (int i = 0; i < 2; i++) {

                System.out.println(Dog[i]);
            }

        String[] Dog2 = new String[2];
        Dog2[0] = "Bim";
        Dog2[1] = "Bars";
        for (int i = 0; i < 2; i++) {
            System.out.println(Dog2[i]);
        }

        }
    }
