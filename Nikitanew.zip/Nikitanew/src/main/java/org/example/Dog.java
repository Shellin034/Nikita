package org.example;

public class Dog {
    int age;
    String name;

    public Dog(int age, String name) {
        this.age = age;
        this.name = name;

    }
    public void printInfo() {
        System.out.println(name + " " + age);
    }
}